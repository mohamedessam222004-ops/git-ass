
const path = require("path");
const fs = require("fs");
const os = require("os");
const EventEmitter = require("events");
const zlib = require("zlib");
const { pipeline } = require("stream");


// Q1

function logPath() {
    console.log(`{File: "${__filename}", Dir: "${__dirname}"}`);
}

logPath();


// Q2

function getFileName(filePath) {
    return path.basename(filePath);
}

console.log(getFileName("/user/files/report.pdf"));


// Q3

function buildPath(obj) {
    return path.join(obj.dir, obj.name + obj.ext);
}

console.log(buildPath({
    dir: "/folder",
    name: "app",
    ext: ".js"
}));


// Q4

function getExtension(filePath) {
    return path.extname(filePath);
}

console.log(getExtension("/docs/readme.md"));


// Q5

function parsePath(filePath) {
    const parsed = path.parse(filePath);

    return {
        Name: parsed.name,
        Ext: parsed.ext
    };
}

console.log(parsePath("/home/app/main.js"));


// Q6

function checkAbsolute(filePath) {
    return path.isAbsolute(filePath);
}

console.log(checkAbsolute("/home/user/file.txt"));



// Q7


function joinPaths(...parts) {
    return path.join(...parts);
}

console.log(joinPaths("src", "components", "App.js"));



// Q8


function resolvePath(filePath) {
    return path.resolve(filePath);
}

console.log(resolvePath("./index.js"));


// Q9


function joinTwoPaths(path1, path2) {
    return path.join(path1, path2);
}

console.log(joinTwoPaths("/folder1", "folder2/file.txt"));



// Q10


function deleteFile(filePath) {
    fs.unlink(filePath, (err) => {
        if (err) {
            console.log(err.message);
            return;
        }

        console.log("The file is deleted.");
    });
}

deleteFile("./file.txt");



// Q11


function createFolder(folderName) {
    try {
        fs.mkdirSync(folderName);
        console.log("Success");
    } catch (err) {
        console.log(err.message);
    }
}

createFolder("./newFolder");


// Q12


const emitter1 = new EventEmitter();

emitter1.on("start", () => {
    console.log("Welcome event triggered!");
});

emitter1.emit("start");



// Q13


const emitter2 = new EventEmitter();

emitter2.on("login", (username) => {
    console.log(`User logged in: ${username}`);
});

emitter2.emit("login", "Ahmed");


// Q14

function readFile(filePath) {
    const data = fs.readFileSync(filePath, "utf8");
    console.log(data);
}

readFile("./notes.txt");


// Q15

fs.writeFile("./async.txt", "Async save", (err) => {
    if (err) {
        console.log(err.message);
        return;
    }

    console.log("File written successfully");
});



// Q16

function checkExists(filePath) {
    return fs.existsSync(filePath);
}

console.log(checkExists("./notes.txt"));



// Q17

function getOSInfo() {
    return {
        Platform: os.platform(),
        Arch: os.arch()
    };
}

console.log(getOSInfo());


// Q18

const stream = fs.createReadStream("./big.txt", {
    encoding: "utf8"
});

stream.on("data", (chunk) => {
    console.log(chunk);
});

stream.on("end", () => {
    console.log("Finished reading");
});


// Q19

const readable = fs.createReadStream("./source.txt");
const writable = fs.createWriteStream("./dest.txt");

readable.pipe(writable);

writable.on("finish", () => {
    console.log("File copied using streams");
});


// Q20

const readStream = fs.createReadStream("./data.txt");
const gzip = zlib.createGzip();
const writeStream = fs.createWriteStream("./data.txt.gz");

pipeline(
    readStream,
    gzip,
    writeStream,
    (err) => {
        if (err) {
            console.log(err.message);
        } else {
            console.log("File compressed successfully");
        }
    }
);








