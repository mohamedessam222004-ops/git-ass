const http = require("http");
const fs = require("fs");

const PORT = 3000;


// Read users from JSON file
function readUsers() {
    const data = fs.readFileSync("./users.json", "utf8");
    return JSON.parse(data);
}


// Write users to JSON file
function writeUsers(users) {
    fs.writeFileSync(
        "./users.json",
        JSON.stringify(users, null, 2)
    );
}


// Send response
function sendResponse(res, statusCode, data) {
    res.writeHead(statusCode, {
        "Content-Type": "application/json"
    });

    res.end(JSON.stringify(data));
}


const server = http.createServer((req, res) => {

   // =====================================
// POST /user
// Add User
// =====================================

if (req.method === "POST" && req.url === "/user") {

    let body = "";

    req.on("data", (chunk) => {
        body += chunk.toString();
    });

    req.on("end", () => {

        
        if (!body) {
            return sendResponse(res, 400, {
                message: "Request body is empty"
            });
        }

        let newUser;

        try {
            newUser = JSON.parse(body);
        } catch (error) {
            return sendResponse(res, 400, {
                message: "Invalid JSON"
            });
        }

        const users = readUsers();

        const emailExists = users.find(
            user => user.email === newUser.email
        );

        if (emailExists) {
            return sendResponse(res, 400, {
                message: "Email already exists"
            });
        }

        
        newUser.id = users.length + 1;

        users.push(newUser);

        
        writeUsers(users);

        sendResponse(res, 201, {
            message: "User added successfully"
        });
    });

    return;
}

    // =====================================
    // 2. PATCH /user/:id
    // Update User
    // =====================================

    if (req.method === "PATCH" && req.url.startsWith("/user/")) {

        const id = Number(req.url.split("/")[2]);

        let body = "";

        req.on("data", (chunk) => {
            body += chunk;
        });

        req.on("end", () => {

            const updates = JSON.parse(body);

            const users = readUsers();

            const user = users.find(
                user => user.id === id
            );

            if (!user) {
                return sendResponse(res, 404, {
                    message: "User not found"
                });
            }

            if (updates.name) {
                user.name = updates.name;
            }

            if (updates.age) {
                user.age = updates.age;
            }

            if (updates.email) {
                user.email = updates.email;
            }

            writeUsers(users);

            sendResponse(res, 200, {
                message: "User updated successfully",
                user: user
            });
        });

        return;
    }


    // =====================================
    // 3. DELETE /user/:id
    // Delete User
    // =====================================

    if (req.method === "DELETE" && req.url.startsWith("/user/")) {

        const id = Number(req.url.split("/")[2]);

        const users = readUsers();

        const userIndex = users.findIndex(
            user => user.id === id
        );

        if (userIndex === -1) {
            return sendResponse(res, 404, {
                message: "User not found"
            });
        }

        users.splice(userIndex, 1);

        writeUsers(users);

        sendResponse(res, 200, {
            message: "User deleted successfully"
        });

        return;
    }


    // =====================================
    // 4. GET /user
    // Get All Users
    // =====================================

    if (req.method === "GET" && req.url === "/user") {

        const users = readUsers();

        sendResponse(res, 200, users);

        return;
    }


    // =====================================
    // 5. GET /user/:id
    // Get User By ID
    // =====================================

    if (req.method === "GET" && req.url.startsWith("/user/")) {

        const id = Number(req.url.split("/")[2]);

        const users = readUsers();

        const user = users.find(
            user => user.id === id
        );

        if (!user) {
            return sendResponse(res, 404, {
                message: "User not found"
            });
        }

        sendResponse(res, 200, user);

        return;
    }


    // =====================================
    // Route Not Found
    // =====================================

    sendResponse(res, 404, {
        message: "Route not found"
    });

});


server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});